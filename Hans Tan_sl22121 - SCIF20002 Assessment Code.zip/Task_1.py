import numpy as np 
import matplotlib.pyplot as plt
import time

from mpl_toolkits.mplot3d import Axes3D #To plot a 3D Graph of the trajectories. 

class NBodySimulation_T1:
    """
    A class to simulate the N-body dynamics of particles using dimensionless units.

    It also models the behaviour of a system of particles interacting through the Lennard Jones Potential. It outlines the particles' trajectories.  

    Parameters :
    -----
    positions : ndarray 
        Initial positions of the particles - shaped (N,3) - where N is the number of particles. 
    velocities : ndarray 
        Inital velocities of the particles - shaped (N,3) 
    masses : ndarray 
        Masses of the particles , shaped (N,)
    dt : float
        Time step for simulation - default is 0.01
    ma : float 
        Mass unit for rescaling - default is 1.0 
    sigma : float
        Length unit for rescaling - default is 1.0 
    epsilon : float
        Energy unit for rescaling - default is 1.0
    """
    def __init__(self, positions, velocities, masses, dt=0.01, ma=1.0, sigma=1.0, epsilon=1.0):
        """Initialise the essential variables needed for the simulation in dimensionless units """
        #Rescaled Parameters
        self.sigma = sigma
        self.ma = ma 
        self.epsilon = epsilon 
        self.tau = np.sqrt(ma * sigma **2 / epsilon ) #This is the characteristic timescale
        
        #Rescaled parameters
        self.dt = dt / self.tau #Rescaled time
        self.positions = np.array(positions) / sigma #Rescaled positions
        self.masses = np.array(masses) /ma #Rescaled mass
        self.velocities = np.array(velocities) / (sigma / self.tau) #Rescaled Velocity
        
        #Number of particles 
        self.num_particles = len(positions)
        
        #initiliase forces as a zero array with same shape as positions. 
        self.forces = np.zeros_like(self.positions)

    def print_char(self):
        """
        Prints the characteristic timescale and speed for the simulation based on the provided dimensionless units.  
        """
        print(f"The Characteristic Timescale for this particle(τ) is:{self.tau} units")
        print(f"The Characteristic speed (σ/τ) is:{self.sigma/self.tau} units/s")
        
    def update_forces(self):
        """Updates the net force for ALL particles due to pairwise Lennard-Jones Force using vectorised method """
        
        #Set forces back to zero again for all particles 
        self.forces = np.zeros((self.num_particles,3))
        
        #Create displacement vector for all particles - the 3D array will have SIZE [n,n,3]
        #First n is the source particle, second n is the target particle, 3 is the dimensions of the particle - x,y,z
        
        displacements = self.positions[np.newaxis,:,:] -  self.positions[:,np.newaxis,:]
        
        #Calculate euclidean distance between all particles - SIZE [n,n]
        #First n is source particle , second n is the target particle
        #Each element [i,j] reperesents the distance between particle i and particle j  
        distances = np.linalg.norm(displacements , axis = 2)
        
        #Avoid division by zero. Set the 0 distances to infinity so that we divide by infinity first 
        corrected_distances = np.where(distances > 0 , distances, np.inf) 
        
        #Calculate Lennard=Jones force magnitude
        r_inv = 1/corrected_distances 
        r_inv13 = r_inv**13
        r_inv7 = r_inv**(7)
        
        #force_magnitude has SIZE [n,n]
        force_magnitudes = 24 * (-2 * r_inv13 + r_inv7)
        
        #forces has size [n,n,3]
        #First n is the source particle, second n is the target particle, 3 is the dimensions of the particle  - x,y,z
        forces = force_magnitudes[:,:,np.newaxis] * (displacements * r_inv[:,:,np.newaxis])
        
        #Sums up all force vector for each particle across second dimension 
        #self.forces has shape [n,3]
        self.forces = np.sum(forces,axis=1)
        
    def verlet_leap_frog_integration_step(self):
        """
        Performs one step of the Verlet Integration to update the postions and velocities of the particles. 
        This uses the proposed process in the Final Assessment document. 
        """
        # Update velocities with half the timestep first.
        accelerations = self.forces 
        self.velocities += 0.5 * accelerations * self.dt
        
        # Update positions with full timestep.
        self.positions += self.velocities * self.dt

        # Update forces before the second half of the velocities update.
        self.update_forces()
        
        # Complete velocities update with the second half of the timestep.
        new_accelerations = self.forces 
        self.velocities += 0.5 * new_accelerations * self.dt
        
    def trajectories(self,steps):
        """Calculates the position of all particles over the desired number of time-steps. 
        Parameters: 
        ----
        steps : int
            Number of time steps to simulate 

        Returns: 
        ----
        trajectories : ndarray 
            A 3D array of shape (steps+1, num_particles, 3) containing the position of all particles at every time-step.   
        """
        #Basically each layer has all of the particles , and each layers represents a different time-step
        trajectories = np.zeros((steps + 1, self.num_particles, 3)) #3D Numpy array
        #Copies initial position of all particles into the first "layer"
        trajectories[0] = self.positions.copy()
        
        for i in range(steps):
            self.verlet_leap_frog_integration_step()
            trajectories[i+1] = self.positions.copy() #copying the position at each time step
        
        return trajectories
    
    def plot_particle_trajectories(self, num_steps):
        """Plots the particle trajectories in the x-y-z plane over time.

        Parameters: 
        ----
        num_steps : int 
            Number of simulation steps to plot the positions. 
        """
        trajectories = self.trajectories(num_steps)

        # Create a 3D figure
        fig = plt.figure(figsize=(10,8))
        ax = fig.add_subplot(111, projection='3d')

        # Prepare the data for 3D plotting
        # Iterate over each particle's trajectory, appending NaNs to break lines
        # : - refers to all of the time-steps , i refers to a specific row in the matrices , the numbers reperesent the column 
        
        for i in range(self.num_particles):
            ax.plot(trajectories[:, i, 0], trajectories[:, i, 1], trajectories[:, i, 2], linestyle = '--', label=f'Particle {i+1}')

        # Set labels and title
        ax.set_xlabel('X (dimensionless units)')
        ax.set_ylabel('Y (dimensionless units)')
        ax.set_zlabel('Z (dimensionless units)')
        ax.set_title('3D Trajectories of Particles')

        plt.legend()
        plt.show()
        
    def plot_relative_distance(self,num_steps):
        """
        Plots the relative distances between pairs of particles over time.

        Parameters: 
        ---- 
        num_steps : int
            Number of simulation steps required to plot the relative distances for. 
        """
        # Setup the figure for relative distances
        trajectories = self.trajectories(num_steps)
        
        plt.figure(figsize=(12, 6))
        
        # Calculate and plot the relative distances
        for i in range(self.num_particles - 1):
            for j in range(i + 1, self.num_particles):
                relative_distances = np.linalg.norm(trajectories[:, i] - trajectories[:, j], axis=1)
                plt.plot(np.arange(num_steps+1) * self.dt, relative_distances, label=f'Distance between P{i+1} & P{j+1}')
        
        plt.xlabel('Time (dimensionless units)')
        plt.ylabel('Relative Distance (dimensionless units)')
        plt.title('Relative Distance of Particles Over Time')
        plt.legend()
        plt.grid(True)
        plt.show()