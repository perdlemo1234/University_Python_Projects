import numpy as np 
import matplotlib.pyplot as plt
import time 
import pandas as pd

#To plot a 3D Graph of the trajectories.
from mpl_toolkits.mplot3d import Axes3D 
#Extracting class from the first python file 
from Task_1 import NBodySimulation_T1

#Subclass - Task 2
class NBodySimulation_T2(NBodySimulation_T1):
    """
    A class to simulate the N-body dynamics of particles using dimensionless units ( Task 1. ) 
    
    The simulation is added now with boundaries ( simulating a box scenario ). ( Task 2)

    Parameters ( Task 2 ) : 
    ----
    L : float 
        Length of the sides of the cubic box. Default is 10
    """
    def __init__(self, positions, velocities, masses, dt=0.01, ma=1.0, sigma=1.0, epsilon=1.0, L=10):
        """Add a new variable L ( Task 2 )"""
        super().__init__(positions, velocities, masses, dt, ma , sigma, epsilon) #Call the constructor from Task 1
        
        self.L = L #Side length of the cubic box

    def handle_boundary_conditions(self):
        """
        Corrects position and reverses the velocity if a particle hits the cubic box wall.( Task 2 )
        """
        #Identify particles beyond the positive boundary in all dimensions
        out_of_bounds_pos = self.positions > self.L / 2
        self.positions[out_of_bounds_pos] = self.L /2 #Correct position to be on the boundary 
        self.velocities[out_of_bounds_pos] *= -1 #Reverse Velocity - keeping magnitude 
        
        #Identify particles beyond the negative boundary in all dimensions 
        out_of_bounds_neg = self.positions < -self.L / 2
        self.positions[out_of_bounds_neg] = -self.L / 2 #Correct position to be exactly on the boundary 
        self.velocities[out_of_bounds_neg] *= -1 #Reverse Velocity 
                
    def verlet_leap_frog_integration_step(self):
        """
        Performs one step of the Verlet Integration to update the postions and velocities of the particles. 
        This uses the proposed process in the Final Assessment document. (Task 1) 
           
        Handles boundary conditions to ensure particles remain within the cubic box. ( Task 2 ). 
        """
        self.update_forces()
        
        # Update velocities with half the timestep first.
        accelerations = self.forces 
        self.velocities += 0.5 * accelerations * self.dt
        
        # Update positions with full timestep.
        self.positions += self.velocities * self.dt

        #Apply the boundary conditions to correct positions and velocities as needed 
        self.handle_boundary_conditions()

        # Update forces before the second half of the velocities update.
        self.update_forces()
        
        # Complete velocities update with the second half of the timestep.
        new_accelerations = self.forces 
        self.velocities += 0.5 * new_accelerations * self.dt
        
    def sim_particle_bouncing(self,steps): 
        """
        Runs the simulation for a given number of steps and plots the trajectory of the first particle OR ONE particle ( Task 2 ). 
        
        Parameters:
        - steps: Number of simulation steps to run.
        """
        #Stores positions of ONE particle throughout time in 3D
        trajectory = np.zeros((steps + 1, 3)) 
        trajectory[0] = self.positions[0]

        for step in range(1, steps + 1):
            self.verlet_leap_frog_integration_step() #Moves ALL particles 
            trajectory[step] = self.positions[0] #Captures position of ONE particular particle 
            
        #Plotting the trajectory 
        plt.figure()
        plt.plot(trajectory[:, 0], trajectory[:, 1], label='Y Trajectory', linestyle ='-')
        plt.plot(trajectory[:, 0], trajectory[:, 2], label='Z Trajectory')
        
        #Plot a singular red dot at the centre of the box 
        plt.scatter(0,0,color='black', s=40, label='Centre of the box')
        
        #Drawing the box boundaries
        plt.axhline(y=-self.L/2, color = 'r', linestyle = '--')
        plt.axhline(y=self.L/2, color = 'r', linestyle = '--')
        plt.axvline(x=-self.L/2, color = 'r', linestyle = '--')
        plt.axvline(x=self.L/2, color = 'r', linestyle = '--')
        
        #Adding labels and a title to the graph 
        plt.xlabel('X Position') 
        plt.ylabel('Y/Z Position')
        plt.title('Singular Particle Trajectory in a Box')
        
        plt.legend()
        plt.grid(True)
        plt.show()
        
    def plot_particle_velocity(self, num_steps):
        """
        Runs the simulation for a given number of steps and plots the x, y, and z velocities
        of the first particle over time. ( Task 2 ) 

        Parameters:
        - num_steps: Number of simulation steps to run.
        """
        # Initialize arrays to store velocity components for the first particle (+1 is to include the initial conditions ) 
        velocity_x = np.zeros(num_steps + 1)
        velocity_y = np.zeros(num_steps + 1)
        velocity_z = np.zeros(num_steps + 1)
        
        # Record the initial velocities
        velocity_x[0], velocity_y[0], velocity_z[0] = self.velocities[0]

        # Run the simulation and record velocities
        for step in range(1, num_steps + 1):
            self.verlet_leap_frog_integration_step()  # Moves ALL particles
            velocity_x[step], velocity_y[step], velocity_z[step] = self.velocities[0]

        # Create plots for the velocity components
        plt.figure(figsize=(12, 4))
        # Create an array with the time steps - times at which each step of the simulation occurs ( every dt ) 
        time_steps = np.arange(num_steps + 1) * self.dt  

        # X Velocity
        plt.subplot(1, 3, 1)
        plt.plot(time_steps, velocity_x, color='r', label='X Velocity')
        plt.xlabel('Time')
        plt.ylabel('Velocity')
        plt.title('X Component of Velocity')
        plt.grid(True)

        # Y Velocity
        plt.subplot(1, 3, 2)
        plt.plot(time_steps, velocity_y, color='g', label='Y Velocity')
        plt.xlabel('Time')
        plt.title('Y Component of Velocity')
        plt.grid(True)

        # Z Velocity
        plt.subplot(1, 3, 3)
        plt.plot(time_steps, velocity_z, color='b', label='Z Velocity')
        plt.xlabel('Time')
        plt.title('Z Component of Velocity')
        plt.grid(True)

        # Show the plot with a tight layout
        plt.tight_layout()
        plt.show()
        
    def calculate_kinetic_energy(self, num_steps, window_size=5, output='No'): 
        """
        Runs the simulation for a given number of steps and calculates the kinetic energy over time. ( Task 2 ) 

        Parameters:
        ----
        - num_steps: Number of simulation steps to run
        - window_size: Number of Sequential data points to calculate the average over. 
        
        Returns: 
        ----
        kinetic_energy_over_time : Kinetic energy of particles over time
        moving_average : Average of kinetic_energy given the window size - to smoothen the graph.
        
        """
        start = time.time() 
        
        #Initialise an array to store total kinetic energy
        kinetic_energy = np.zeros(num_steps + 1)
 
        #Record Initial Kinetic Energy
        initial_speed = np.linalg.norm(self.velocities)
        kinetic_energy[0] = 0.5 * self.masses[0] * initial_speed**2

        # Run the simulation and calculate kinetic energy at each step
        for step in range(1, num_steps + 1):
            self.verlet_leap_frog_integration_step()
            speed = np.linalg.norm(self.velocities)
            kinetic_energy[step] = 0.5 * self.masses[0] * speed**2
        
        if (output == 'Yes'):
            print(f"Time to calculate kinetic energy is {time.time() - start} seconds")
        
        #Record Time before calculating rolling average
        rolling_start = time.time()
        
        #Create a Pandas DataFrame with kinetic energy values and time_step 
        data = pd.DataFrame({'time_step': range(num_steps+1),'kinetic_energy':kinetic_energy})
        
        #Calculate rolling average for pressure based on window size
        data['rolling_avg'] = data.kinetic_energy.rolling(window_size).mean()
        
        rolling_average = data['rolling_avg']
        
        # End timing calculation for rolling average 
        rolling_duration = time.time() - rolling_start
        
        if (output == 'Yes'):
            print(f"Time to calculate the rolling kinetic average is {rolling_duration} seconds. \n")
            print(f"The rolling average temperature over the duration is {np.mean(rolling_average)}")
        
        return kinetic_energy , rolling_average
        
    def plot_kinetic_energy(self,kinetic_energy_over_time, num_steps):
        """
        Plot kinetic energy over time for all particles ( Task 2 ): 
        """        
        #Calculate time-steps for plotting 
        time_steps = np.arange(num_steps+1) * self.dt
        
        # Plot the kinetic energy over time
        plt.figure(figsize=(10, 5))
        plt.plot(time_steps, kinetic_energy_over_time, label='Kinetic Energy')
        plt.xlabel('Time')
        plt.ylabel('Kinetic Energy')
        plt.title('Kinetic Energy Over Time')
        plt.axhline( y = np.mean(kinetic_energy_over_time), color = 'r', linestyle = '--', label = 'Mean')
        plt.legend()
        plt.grid(True)
        plt.show()
        