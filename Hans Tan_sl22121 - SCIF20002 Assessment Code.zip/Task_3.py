import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd 
import time 
from sklearn.metrics import r2_score

#To plot a 3D Graph of the trajectories.
from mpl_toolkits.mplot3d import Axes3D 
#Extracting class from the first python file 
from Task_2 import NBodySimulation_T2

#Subclass derived from Task_2 
class NBodySimulation_T3(NBodySimulation_T2):
    """
    A class to simulate the N-body dynamics of particles using dimensionless units ( Task 1. ) 
    
    The simulation is added now with boundaries ( simulating a box scenario ). ( Task 2)

    Calculate Pressure, Volume and Temperature of the gas. Since the method temperature was calculated in Task 2, we can ignore this aspect. ( Task 3) 
    """
    def __init__(self, positions, velocities, masses, dt=0.01, ma=1.0, sigma=1.0, epsilon=1.0, L=10):
        """
        All the parameters remains the same from Task 2, so we only need to call the established constructor from Task 2
        """
        #Call constructor from Task 2 
        super().__init__(positions, velocities, masses, dt, ma , sigma, epsilon,L)
        
    def calculate_directional_pressure(self , num_steps, direction, plane_side, window_size, output ='No'): 
        """
        Calculates the pressure of the gas based on momentum of the particles based on the dt value.  ( Task 3 ) 
        
        Parameters: 
        ----
        num_steps : Total number of steps needed to be taken 
        direction : X, Y, or Z
        plane_side : Either Positive or Negative , since the center of the 3D Grid is in the middle of the box 
        window_size : Number of Sequential data points to calculate the average over. 
        output : Determines if we should output 
        
        Returns: 
        ----
        pressure_over_time : Pressure in any given direction throughout time 
        moving_average : Average of pressure given the window size - to smoothen the graph. 
        
        """
        start = time.time()
        
        # Area of the plane - it doesn't matter since it's a cube 
        A = self.L ** 2 
        
        # Intialise an array to store pressure values at each time-step 
        pressure_over_time = np.zeros(num_steps+1) 
        
        #User allowed to choose either direction 
        dir_index = { 'X':0 , 'Y':1, 'Z':2 } [direction]
        
        #Initialise previous positions
        prev_pos = np.copy(self.positions) 
        
        for step in range( 1, num_steps+1): 
            #Store current position as 'previous' for the next iteration 
            current_pos = np.copy(self.positions) 
            
            #Update position and velocity at specific time-step
            self.verlet_leap_frog_integration_step() 
            
            #Condition where particle crosses a given plane 
            if plane_side == 'Positive': 
                cond_plane = (self.positions[:,dir_index] >= self.L/2) & (prev_pos[:,dir_index] < self.L/2)
                # Calculate the change in momentum for the particles that have made contact with the plane
                #The change of momentum as it hit's the wall is in the negative direciton 
                delta_v = -2 * self.velocities[cond_plane,dir_index]
            else: 
                cond_plane = (self.positions[:,dir_index] <= -self.L/2) & (prev_pos[:,dir_index] > -self.L/2)
                # Calculate the change in momentum for the particles that have made contact with the plane
                #The change of momentum is twice in the positive direciton
                delta_v = 2 * self.velocities[cond_plane,dir_index]
            
            #Total momentum experienced during time-step
            total_momentum = np.sum(self.masses[cond_plane] * delta_v)
            
            #Pressure calculation for this particular step 
            pressure_over_time[step] = total_momentum / (A * self.dt) 
            
            #Update previous position for the next step 
            prev_pos = current_pos 
            
        if (output == 'Yes'):
             print(f"Time to calculate pressure {time.time() - start} seconds")
       
        #Record Time before calculating rolling average
        rolling_start = time.time()
        
        #Create a Pandas DataFrame with pressure values and time_step 
        data = pd.DataFrame({'time_step': range(num_steps+1),'pressure':pressure_over_time})
        
        #Calculate rolling average for pressure based on window size
        data['rolling_avg'] = data.pressure.rolling(window_size).mean()
        
        rolling_average = data['rolling_avg']
        
        # End timing calculation for rolling average 
        rolling_duration = time.time() - rolling_start
        
        if (output == 'Yes'): 
            print(f"The mean of the rolling average pressure in the {plane_side} {direction} direction is {np.mean(rolling_average)}")
            print(f"Time to calculate the rolling pressure average is {rolling_duration} seconds")
        
        return pressure_over_time , rolling_average
        
    def plot_pressure_direction(self, pressure_over_time, num_steps, direction, plane_side): 
        """
        Plot the pressure of cubic box over time in a specfic direction facing either the positive or negative direction ( Task 3 ) 
        """
        #Calculate time-steps for plotting 
        time_steps = np.arange(num_steps+1) * self.dt
                
        plt.figure(figsize=(10,5))
        plt.plot(time_steps, pressure_over_time, label='Pressure') 
        plt.xlabel('Time')
        plt.ylabel('Pressure') 
        plt.title(f'Pressure Over Time in the {direction} {plane_side} Direction')
        plt.grid(True)
        
        #Plot horizontal line to show mean of directional pressure
        plt.axhline(y = np.mean(pressure_over_time), color = 'r', linestyle = '--', label = 'Mean')
        plt.legend()
        plt.show()
        
    def calculate_total_pressure(self,pressure_over_time):    
        """
        Calculate total pressure of cubic box over time within the cubic box. ( Task 3 ) 
        """ 
        #Calculate total pressure 
        pressure = 3 * pressure_over_time
        
        return pressure 
        
    def plot_total_pressure(self, pressure_over_time, num_steps):
        """
        Plot total pressure of cubic box over time within the cubic box. ( Task 3 ) 
        """
        time_steps = np.arange(num_steps+1) * self.dt
        
        pressure = self.calculate_total_pressure(pressure_over_time)
        
        plt.figure(figsize=(10,5))
        plt.plot(time_steps, pressure, label='Pressure') 
        plt.xlabel('Time')
        plt.ylabel('Total Pressure') 
        plt.title(f'Total Pressure of the cubic box')
        plt.grid(True)
        
        #Plot horizontal line to show mean of total pressure
        plt.axhline(y = np.mean(pressure), color = 'r', linestyle = '--', label = 'Mean')
        plt.legend()
        print(f"The mean of the total pressure is {np.mean(pressure)}")
      
        plt.show() 
        
    def plot_pressure_against_temp(self, num_steps, window_size): 
        """
        Plot pressure against temperature over given num_steps while keeeping the positions of the particles same. ( Task 3 )
        
        Parameters: 
        ----
        - num_steps : specifies how many different temperature settings to simulate 
        - window_size : Number of consecutive data to be considered each rolling average. 
        
        Output: 
        - Plot for Pressure Against temperature 
        - Line of Best Fit 
        """
        start = time.time()
        
        #Set up empty arrays for plot 
        temperatures = []
        pressures =[]
        initial_velocities = self.velocities.copy()
        
        for i in range(num_steps): 
            #First, we scale the velocities to simulate different temperatures 
            scale_factor = 1 + (i/20)
            self.velocities = initial_velocities * scale_factor
            
            #Calculate kinetic energy and obtain the rolling average of it 
            _, rolling_temp_average = self.calculate_kinetic_energy(num_steps,window_size, output = 'No')
            avg_temp = np.mean(rolling_temp_average) #Mean of the rolling-average 
            
            #Calculate directional pressure and total pressure 
            _, rolling_directional_pressure_average = self.calculate_directional_pressure(num_steps, 'X','Positive', window_size)
            total_pressure = self.calculate_total_pressure(rolling_directional_pressure_average)
            avg_total_pressure = np.mean(total_pressure)
            
            #Store Results
            temperatures.append(avg_temp) 
            pressures.append(avg_total_pressure) 
            
            #Reset Original Simulation Velocity for next iteration 
            self.velocities = initial_velocities 
            
        print(f"Time taken to calculate values for plot is {time.time() - start}")
            
        #Calculate line of best fit 
        slope, intercept = np.polyfit(temperatures, pressures, 1)
        line_of_best_fit = np.poly1d((slope, intercept))
        
        #Generate y-values from line of best fit 
        predicted_pressures = line_of_best_fit(temperatures)
        
        #Calculate R-squared score 
        r_squared = r2_score(pressures, predicted_pressures) 
        print(f'R-squared score: {r_squared}')
            
        #Plot the results
        plt.figure(figsize=(10,8))
        plt.scatter(temperatures, pressures, label='Data Points', alpha=0.5) 
        plt.plot(temperatures,predicted_pressures, color = 'red' , label=f' Best Fit Line: Pressure = {slope:.2e} * Temperature + {intercept:.2e}')
        plt.xlabel('Average Temperature') 
        plt.ylabel('Average Total Pressure') 
        plt.title('Pressure Against Temperature')
        
        plt.legend()
        plt.grid(True) 
        plt.show()
        
    def plot_pressure_against_vol(self, num_steps, window_size, combo): 
        """
        Plot pressure against volume over given num_steps while keeeping the positions of the particles same. ( Task 3 )
        
        Parameters: 
        ----
        - num_steps : specifies how many different volume settings to simulate 
        - window_size : Number of consecutive data to be considered for each rolling average. 
        
        Output: 
        - Plot for Pressure Against temperature 
        - Line of Best Fit 
        """
        start = time.time()
        
        #Set up empty arrays 
        volumes = []
        pressures = []
        initial_length = self.L
        
        for i in range (num_steps): 
            #First, we scale the length of the cube to simulate different volume
            scale_factor = 1 + (i/20)
            self.L = initial_length * scale_factor
            volume = self.L**3
                 
            # Modify axis ranges for each dimension and create EVENLY Spaced particles 
            x_range = np.linspace(-self.L/2 + self.sigma, self.L/2 - self.sigma, combo[0])
            y_range = np.linspace(-self.L/2 + self.sigma, self.L/2 - self.sigma, combo[1])
            z_range = np.linspace(-self.L/2 + self.sigma, self.L/2 - self.sigma, combo[2])

            # Create the 3D meshgrid with matrix indexing 
            #.ravel() flattens the matrix into a 1D array 
            # .vstack stacks them vertically on top of each other 
            x, y, z = np.meshgrid(x_range, y_range, z_range, indexing='ij')
            self.positions = np.vstack([x.ravel(), y.ravel(), z.ravel()]).T
        
            #Calculate directional pressure and total pressure 
            _, rolling_directional_pressure_average = self.calculate_directional_pressure(num_steps, 'X','Positive', window_size)
            total_pressure = self.calculate_total_pressure(rolling_directional_pressure_average)
            avg_total_pressure = np.mean(total_pressure)
            
            #Store Results 
            volumes.append(volume)
            pressures.append(avg_total_pressure) 
            
            #Reset the cube length
            self.L = initial_length
                                  
        print(f"Time taken to calculate values for plot is {time.time() - start}")    
        
        #Plot the results 
        plt.figure(figsize=(10,8))
        plt.scatter(volumes, pressures, label='Data Points', alpha=0.5) 
        plt.xlabel('Volume') 
        plt.ylabel('Average Total Pressure') 
        plt.yscale('log') #Set y-axis to log scale 
        plt.title('Pressure Against Volume')
        plt.legend()
        plt.grid(True) 
        plt.show()